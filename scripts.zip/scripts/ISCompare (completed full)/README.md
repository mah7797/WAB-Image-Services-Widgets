## IS Compare ##
### Overview ###
The IS Compare widget sets transparency or swipe on the topmost imagery layer. This enables comparison between the topmost image layer and those below. Typically this would be between the primary and secondary layer, but if there is a results layer then this would be between the results layer and the primary layer.

define({
    root:{
        error : "IS ChangeDetection works with two scenes of different dates. Use IS ImageSelector to define a scene to compare with.<br/>Select a scene using the IS ImageSelector and then click on the <img src='widgets/ISChangeDetection/images/down.png' height='20'/> button. Return to this control to proceed with change detection."
    },
    "zh-cn": true    
});
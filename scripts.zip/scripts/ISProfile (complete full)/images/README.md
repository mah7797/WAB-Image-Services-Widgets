## IS Profile ##
### Overview ###
The IS Profile widget shows temporal, spectral or indices profile of a point on the primary layer.
## IS Renderer ##
### Overview ###
The IS Renderer widget sets the service functions/stretch on the primary layer. The drop down in the widget is automatically populated with the service functions of the primary layer.

define({
    root:{
        layerSaved: "Layer is already saved.",
        restricted: "Restricted.Please rename.",
        entername : "Enter the name:",
        overwrite : "Name already exists in the Layer list. Do you want to overwrite it?",
        resultsave : "Save the Result layer in the layer list",
        copy : "Copy primary to secondary",
        swap :"Swap primary and secondary"
    },
    "zh-cn": true    
});
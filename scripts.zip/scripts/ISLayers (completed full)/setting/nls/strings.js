define({
  root: {
    arrangement: "Arrangement",
    autoUpdate: "Auto Update",
    respectCurrentMapScale: "Respect Current Map Scale"
  },
  "zh-cn": true
});
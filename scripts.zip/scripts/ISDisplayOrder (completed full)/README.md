## IS DisplayOrder ##
### Overview ###
The IS Display Order widget sets the mosaic rule on the primary layer.

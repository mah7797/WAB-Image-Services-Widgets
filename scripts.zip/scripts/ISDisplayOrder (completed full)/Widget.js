///////////////////////////////////////////////////////////////////////////
// Copyright (c) 2013 Esri. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////
define([
    'dojo/_base/declare',
    'dijit/_WidgetsInTemplateMixin',
    'jimu/BaseWidget',
    "dijit/registry",
    "dojo/_base/lang",
    "dojo/html",
    "dojo/dom-style",
    "esri/request",
    "esri/layers/MosaicRule",
    "esri/toolbars/draw",
    "esri/graphic",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/Color", "dojo/date/locale",
    'dojo/dom-construct',
    "dojo/parser",
    "dijit/form/Select",
    "dijit/form/HorizontalSlider",
    "dijit/form/Button",
    "dijit/form/NumberSpinner",
    "dijit/form/CheckBox",
    "dijit/form/HorizontalRuleLabels",
    "dijit/form/TextBox",
    "dijit/form/DateTextBox"
],
        function (
                declare,
                _WidgetsInTemplateMixin,
                BaseWidget,
                registry, lang, html, domStyle, esriRequest, MosaicRule, Draw, Graphic, SimpleMarkerSymbol, SimpleLineSymbol, Color, locale, domConstruct) {
            var clazz = declare([BaseWidget, _WidgetsInTemplateMixin], {
                name: 'ISDisplayOrder',
                baseClass: 'jimu-widget-ISDisplayOrder',
                previousImageServiceLayerUrl: null,
                imageServiceLayer: null,
               

                startup: function () {
                    this.inherited(arguments);
                    domConstruct.place('<img id="loadingDisplayOrder" style="position: absolute;top:0;bottom: 0;left: 0;right: 0;margin:auto;z-index:100;" src="' + require.toUrl('jimu') + '/images/loading.gif">', this.domNode);
                    this.hideLoading();
                        document.getElementById("mosaicMethod".onchange ,( lang.hitch(this, this.checkFields)));
                   document.getElementById("mrapply".onclick , lang.hitch(this, this.applyMosaic));
              document.getElementById("sortField".onchange , lang.hitch(this, function (value) {
                        if (this.saveFields[value] === "esriFieldTypeDate") {
                            domStyle.set(document.getElementById("sortValueDate"), "display", "inline-block");
                            domStyle.set(document.getElementById("sortValue"), "display", "none");
                        } else {
                            domStyle.set(document.getElementById("sortValueDate"), "display", "none");
                            domStyle.set(document.getElementById("sortValue"), "display", "inline-block");
                        }

                    }));
                },
postCreate: function(){   
                    if (this.map) {
                        this.map.on("update-start", lang.hitch(this, this.showLoading));
                        this.map.on("update-end", lang.hitch(this, this.hideLoading));
                    }
                    this.toolbarDisplayOrder = new Draw(this.map);
                   dojo.connect(this.toolbarDisplayOrder, "onDrawComplete", lang.hitch(this, this.addGraphic));
                },
              
                onOpen: function () {
                    this.refreshData();
                    if (this.map) {
                        this.refreshHandler = this.map.on("update-end", lang.hitch(this, this.refreshData));
                    }
                },
                clearGraphic: function () {
                    for (var a in this.map.graphics.graphics) {
                        if (this.map.graphics.graphics[a].geometry && this.map.graphics.graphics[a].geometry.type === "point" && this.map.graphics.graphics[a].symbol && this.map.graphics.graphics[a].symbol.color.r === 255) {
                            this.map.graphics.remove(this.map.graphics.graphics[a]);
                            break;
                        }
                    }
                },
                onClose: function () {
                    if (this.refreshHandler) {
                        this.refreshHandler.remove();
                        this.refreshHandler = null;
                    }
                    this.previousImageServiceLayerUrl = null;
                    this.clearGraphic();
                    this.toolbarDisplayOrder.deactivate();
                },
                addGraphic: function (geometry) {
                    this.clearGraphic();
                    var symbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.STYLE_CIRCLE, 20,
                            new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                    new Color([255, 0, 0]), 1),
                            new Color([255, 0, 0, 0.35]));
                    var graphic = new Graphic(geometry.geometry, symbol);
                    this.map.graphics.add(graphic);
                    this.viewPoint = geometry.geometry;
                },
                refreshData: function () {
                    if (this.map.layerIds) {
                        if (this.map.primaryLayer) {
                            this.imageServiceLayer = this.map.getLayer(this.map.primaryLayer);
                        } else {
                            for (var a = this.map.layerIds.length - 1; a >= 0; a--) {
                                var layerObject = this.map.getLayer(this.map.layerIds[a]);
                                var title = layerObject.arcgisProps && layerObject.arcgisProps.title ? layerObject.arcgisProps.title : layerObject.title;
                                if (layerObject && layerObject.visible && layerObject.serviceDataType && layerObject.serviceDataType.substr(0, 16) === "esriImageService" && layerObject.id !== "resultLayer" && layerObject.id !== "scatterResultLayer" && layerObject.id !== this.map.resultLayer && (!title || ((title).charAt(title.length - 1)) !== "_")) {
                                    this.imageServiceLayer = layerObject;
                                    break;
                                } else
                                    this.imageServiceLayer = null;
                            }
                        }
                        if (this.imageServiceLayer) {
                            domStyle.set(this.displayOrderContainer, "display", "block");
                            html.set(this.displayOrderErrorContainer, "");
                            html.set(this.displayOrderLayerTitle, "Layer: <b>" + (this.imageServiceLayer.title || this.imageServiceLayer.arcgisProps.title || this.imageServiceLayer.name || this.imageServiceLayer.id) + "</b>");
                            if (this.previousImageServiceLayerUrl !== this.imageServiceLayer.url) {
                                this.populateAttributes();
                                this.checkFields();
                            }
                        } else {
                            domStyle.set(this.displayOrderContainer, "display", "none");
                            html.set(this.displayOrderErrorContainer, "No visible Imagery Layers in the map.");
                        }
                    }
                },
        
      
                populateAttributes: function () {
                    this.previousImageServiceLayerUrl = this.imageServiceLayer.url;
                    if (this.imageServiceLayer.fields)
                    
                    {
                        this.saveFields = [];
                          for (var i = 0; i < this.imageServiceLayer.fields.length; i++) {
                               this.addSelectOption(document.getElementById("sortField"), this.imageServiceLayer.fields[i].name , this.imageServiceLayer.fields[i].name);
                          this.saveFields[this.imageServiceLayer.fields[i].name] = this.imageServiceLayer.fields[i].type;
                      }
                        if (this.saveFields[this.imageServiceLayer.fields[0].name] === "esriFieldTypeDate") {
                            domStyle.set(document.getElementById("sortValueDate"), "display", "inline-block");
                            domStyle.set(document.getElementById("sortValue"), "display", "none");
                        } else {
                            domStyle.set(document.getElementById("sortValueDate"), "display", "none");
                            domStyle.set(document.getElementById("sortValue"), "display", "inline-block");
                        }
                        this.displaymosaic();
                    } else {


                        var request = esriRequest({
                            url: this.imageServiceLayer.url,
                            content: {
                                f: "json"
                            },
                            handleAs: "json",
                            callbackParamName: "callback"
                        });

                        request.then(lang.hitch(this, function (data) {
                    
                            this.saveFields = [];
                            for (var i = 0; i < data.fields.length; i++) {
                              this.addSelectOption(document.getElementById("sortField"), this.imageServiceLayer.fields[i].name , this.imageServiceLayer.fields[i].name);
                                this.saveFields[data.fields[i].name] = data.fields[i].type;
                            }

                            if (this.saveFields[data.fields[0].name] === "esriFieldTypeDate") {
                                domStyle.set(document.getElementById("sortValueDate"), "display", "inline-block");
                                domStyle.set(document.getElementById("sortValue"), "display", "none");
                            } else {
                                domStyle.set(document.getElementById("sortValueDate"), "display", "none");
                                domStyle.set(document.getElementById("sortValue"), "display", "inline-block");
                            }
                            this.displaymosaic();
                        }), function (error) {
                            console.log("Request failed");
                        });
                    }
                },
                displaymosaic: function () {
                    if (this.imageServiceLayer.mosaicRule) {
                        var mosaic = new MosaicRule(this.imageServiceLayer.mosaicRule);
                        document.getElementById("mosaicMethod").setvalue , mosaic.method;
                        document.getElementById("mosaicOperation").setvalue, mosaic.operation;
                        if (mosaic.method !== "esriMosaicSeamline") {
                            document.getElementById("ascending").setChecked , !mosaic.ascending;
                        } else {
                            document.getElementById("ascending").setChecked, (false);
                        }
                        if (mosaic.method !== "esriMosaicSeamline") {

                        if (mosaic.method === "esriMosaicAttribute") {
                            document.getElementByid("sortField").setvalue ,mosaic.sortField;
                            if (this.saveFields[mosaic.sortField] === "esriFieldTypeDate") {
                                document.getElementById("sortValueDate").setvalue , locale.format(new Date(mosaic.sortValue), {selector: "date", datePattern: "yyyy-MM-dd"});
                            } else {
                                document.getElementById("sortValue").setvalue, mosaic.sortValue;
                            }
                        }

                        if (mosaic.method === "esriMosaicLockRaster") {
                            document.getElementById("lockRasterIds").value, mosaic.lockRasterIds.toString();
                        }
                    } else {
                        document.getElementById("mosaicMethod").setvalue ,"esriMosaicNone";
                    }

                }
            },
                checkFields: function () {
                    this.clearGraphic();
                    this.toolbarDisplayOrder.deactivate();
                    switch (document.getElementById("mosaicMethod").getvalue) {
                        case "esriMosaicAttribute" :
                        {
                            domStyle.set(this.attribute), "display", "block";
                            domStyle.set(this.dropDownDisplayOrderOptions), "display", "inline";
                            domStyle.set(this.lockraster), "display", "none";
                            domStyle.set(this.notseamline) , "display", "block";
                            if (!document.getElementById("mosaicOperation") , this.addSelectOption('MT_MIN')) {
                                this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Minimum of pixel values', value: 'MT_MIN'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Maximum of pixel values', value: 'MT_MAX'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Average of pixel values', value: 'MT_MEAN'}));
                            }
                            break;
                        }
                        case "esriMosaicNone" :

                        case "esriMosaicCenter" :

                        case "esriMosaicNorthwest" :

                        case "esriMosaicNadir" :
                        {
                            domStyle.set(this.attribute), "display", "none";
                            domStyle.set(this.dropDownDisplayOrderOptions), "display", "inline";
                            domStyle.set(this.lockraster), "display", "none";
                            domStyle.set(this.notseamline), "display", "block";
                            if (document.getElementById("mosaicOperation"), this.addSelectOption('MT_MIN')) {
                           this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Minimum of pixel values', value: 'MT_MIN'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Maximum of pixel values', value: 'MT_MAX'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Average of pixel values', value: 'MT_MEAN'}));
                            }
                            break;
                        }

                        case "esriMosaicSeamline" :
                        {
                            domStyle.set(this.attribute) ,"display", "none";
                            domStyle.set(this.dropDownDisplayOrderOptions), "display", "inline";
                            domStyle.set(this.lockraster) ,"display", "none";
                            domStyle.set(this.notseamline), "display", "none";
                            document.getElementById("mosaicOperation"),this.removeOption(['MT_MIN', 'MT_MAX', 'MT_MEAN']);
                            break;
                        }
                        case "esriMosaicLockRaster" :
                        {
                            domStyle.set(this.attribute, "display", "none");
                            domStyle.set(this.dropDownDisplayOrderOptions.domNode, "display", "inline");
                            domStyle.set(this.lockraster, "display", "block");
                            domStyle.set(this.notseamline, "display", "block");
                            if (!document.getElementById("mosaicOperation"), this.addSelectOption('MT_MIN')) {
                         this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Minimum of pixel values', value: 'MT_MIN'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Maximum of pixel values', value: 'MT_MAX'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Average of pixel values', value: 'MT_MEAN'}));
                            }
                            break;
                        }
                        case "esriMosaicViewpoint":
                        {
                            domStyle.set(this.attribute), "display", "none";
                            domStyle.set(this.dropDownDisplayOrderOptions.domNode), "display", "inline";
                            domStyle.set(this.lockraster), "display", "none";
                            domStyle.set(this.notseamline), "display", "block";
                            if (!document.getElementById("mosaicOperation") , this.addSelectOption('MT_MIN')) {
                                  this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Minimum of pixel values', value: 'MT_MIN'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Maximum of pixel values', value: 'MT_MAX'}));
                               this.addSelectOption(document.getElementById("mosaicOperation"),({label: 'Average of pixel values', value: 'MT_MEAN'}));
                            }
                            this.toolbarDisplayOrder.activate(Draw.POINT);
                            break;
                        }
                    }
                },
                applyMosaic: function () {
                    var mr = new MosaicRule();
                    mr.method = document.getElementById("mosaicMethod").getvalue;
                    mr.operation = document.getElementById("mosaicOperation").getvalue;
                    switch (document.getElementById("mosaicMethod").getvalue) {
                        case "esriMosaicAttribute" :
                        {
                            mr.ascending = !document.getElementById("ascending").getChecked;
                            mr.sortField = document.getElementById("sortField").getvalue;
                            if (this.saveFields[mr.sortField] === "esriFieldTypeDate") {
                                var date = new Date(document.getElementById("sortValueDate").getvalue);
                                date = date.getFullYear() + "/" + (date.getMonth() + 1) + "/" + date.getDate();
                                mr.sortValue = date;
                            } else
                                mr.sortValue = document.getElementById("sortValue").getvalue;
                            break;
                        }
                        case "esriMosaicNone" :

                        case "esriMosaicCenter" :

                        case "esriMosaicNorthwest" :

                        case "esriMosaicNadir" :
                        {
                            mr.ascending = !document.getElementById("ascending").getChecked;
                            break;
                        }

                        case "esriMosaicSeamline" :
                        {
                            break;
                        }
                        case "esriMosaicLockRaster" :
                        {
                            mr.ascending = !document.getElementById("ascending").getChecked;
                            var temp = document.getElementByid('lockRasterIds').getvalue;
                            var ids = temp.split(',');
                            for (var x in ids) {
                                ids[x] = parseInt(ids[x], 10);
                            }
                            mr.lockRasterIds = ids;
                            break;
                        }
                        case "esriMosaicViewpoint" :
                        {
                            mr.ascending = document.getElementByid("ascending").getChecked;
                            mr.viewpoint = this.viewPoint;
                        }
                    }
                    this.imageServiceLayer.setMosaicRule(mr);
                },
                                    removeSelectOptions: function (domNode) {
            for (var b = domNode.options.length - 1; b >= 0; b--) {
                domNode.remove ,b;
            }
        },            addSelectOption: function ( domNode,label, value) {
            var option = document.createElement("option");
            option.text = label;
            option.value = value;
           domNode.add(option);
                   
      
           
     
        },
                showLoading: function () {
                    domStyle.set("loadingDisplayOrder", "display", "block");
                },
                hideLoading: function () {
                    domStyle.set("loadingDisplayOrder", "display", "none");
                }
           
    });

            clazz.hasLocale = false;
            clazz.hasSettingPage = false;
            clazz.hasSettingUIFile = false;
            clazz.hasSettingLocale = false;
            clazz.hasSettingStyle = false;
            return clazz;
        });
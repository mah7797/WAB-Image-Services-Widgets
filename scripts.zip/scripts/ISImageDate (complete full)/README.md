## IS ImageDate ##
### Overview ###
The IS ImageDate widget shows the date range for the visible rasters, for the current AOI, on the primary layer and the secondary layer.

## IS DisplayParameters ##
### Overview ###
The IS DisplayParameters widget allows users to set interpolation and compression for the primary layer.

## IS Classification ##
### Overview ###
IS Classification widget enables user to draw features, associate categories and then perform classification. The result is then added as the “result layer”. 
